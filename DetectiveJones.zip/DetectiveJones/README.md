# DetectiveJones
"Detective Jones: Unsolved Cases" is my first project build from scratch. It is a detective game, where the player is a new police adept starting his duty with an old, good detective. Pretty classic, but hopefully you will find something interesting in that. Enjoy!

<br><br>

![alt text](https://cdn-images-1.medium.com/max/500/1*JxpsBeS_0dT4ZzJzozGgpw.jpeg)
![alt text](https://cdn-images-1.medium.com/max/500/1*tVoqkMs30Zbg-ZyZnnzsHA.jpeg)
![alt text](https://cdn-images-1.medium.com/max/500/1*mvK7kkCmQRjMgf0MyR41Tw.jpeg)
